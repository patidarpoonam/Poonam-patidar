﻿Imports System.Data.OleDb
Imports System.IO
Partial Class donationbook
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second, third, four, five, six As String
    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Public Sub addnewrecord()
        Dim c2, c3, c4, c5, c6, qinsert As String

        c2 = TextBox1.Text
        c3 = "userid" 'Session("sf")
        c4 = DropDownList1.SelectedItem.Value
        c5 = Today().ToString
        c6 = DropDownList2.SelectedItem.Value
        qinsert = "insert into  SheduleInfo ( Ddate , Donarid , Bloodtype , Bookingdate , Bookingstation ) values ('" & c2 & "','" & c3 & "','" & c4 & "','" & c5 & "','" & c6 & "')"
        Dim cmdInsert As New OleDbCommand(qinsert, cn2)
        cmdInsert.ExecuteNonQuery()
        Response.Write("Data recorded!")
    End Sub
  

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        dbcoon()
        addnewrecord()
        cn2.Close()
    End Sub
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("profiledonar.aspx")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Calendar1.Visible = True

    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        TextBox1.Text = Calendar1.SelectedDate.ToString()
        Calendar1.Visible = False

    End Sub
End Class
