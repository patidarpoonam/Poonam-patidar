﻿Imports System.Data.OleDb
Imports System.IO
Partial Class Donarshistory
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second, third, four, five, six As String
    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Public Sub dbdelete()
        Dim Ssdelete As String

        Ssdelete = "Delete from SheduleInfo where Donarid = '" & TextBox1.Text & "'"
        Dim Cmddelete As New OleDbCommand(Ssdelete, cn2)
        Cmddelete.ExecuteNonQuery()
        'Label1.Text = TextBox1.Text

        TextBox1.Text = ""

        Response.Write("record deleted")

    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        GridView1.Visible = True

    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        TextBox1.Text = GridView1.SelectedValue.ToString
        GridView1.Visible = False
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        dbcoon()
        dbdelete()
        cn2.Close()
    End Sub
End Class
