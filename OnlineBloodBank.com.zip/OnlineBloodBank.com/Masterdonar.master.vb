﻿Imports System.Data.OleDb
Imports System.IO
Partial Class Masterdonar
    Inherits System.Web.UI.MasterPage
    Dim cn2 As OleDbConnection
    Dim first, second As String
    Protected itemcollect As BuildMethod



    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")


    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("sf") = "" Then

            LinkButton1.Text = "Guest"
        Else
            LinkButton1.Text = Session("sf").ToString()
        End If
    End Sub
    Protected Sub LinkButton1_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        If LinkButton1.Text = "Guest" Then
            Response.Redirect("donarlogin.aspx")
        Else
            Session.Abandon()
            Response.Redirect("Default.aspx")
        End If
    End Sub
End Class

