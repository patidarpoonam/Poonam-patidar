﻿Imports System.Data.OleDb
Imports System.IO
Partial Class Updateorder
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second, third, four, five, six As String
    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Public Sub dbsearch()
        Dim c7, Sreach As String
        c7 = TextBox6.Text
        Sreach = "Select Deliveryaddress, Deliverydate, Oquantity, Namepatient, Bloodtype , mobilenumber from OrderInfo where Nid = '" & c7 & "'"
        'Label1.Text = "Word " & c1
        Dim CmdSearch As New OleDbCommand(Sreach, cn2)
        Dim Sread As OleDbDataReader
        Sread = CmdSearch.ExecuteReader
        Dim Sresult As New StringBuilder

        Do While Sread.Read
            first = Sread.GetString(0).ToString()
            second = Sread.GetString(1).ToString()
            third = Sread.GetString(2).ToString()
            four = Sread.GetString(3).ToString()
            five = Sread.GetString(4).ToString()
            six = Sread.GetString(5).ToString()
        Loop
        TextBox1.Text = four
        TextBox2.Text = first
        TextBox3.Text = second
        TextBox4.Text = third
        TextBox5.Text = six
        DropDownList1.Text = five
        Response.Write("Record Searched")
    End Sub
    Public Sub dbupdate()
        Dim c1, c4, c2, c3, c5, c6, c7, Supdate As String
        c4 = TextBox1.Text
        c1 = TextBox2.Text
        c2 = TextBox3.Text
        c3 = TextBox4.Text
        c6 = TextBox5.Text
        c5 = DropDownList1.Text
        c7 = TextBox6.Text
        'Supdate = "update custm1 set roll = 8, cname='bsonkatch', cadd='snkatc',cbalance=1200"
        Supdate = "update OrderInfo set Deliveryaddress='" & c1 & "',Deliverydate='" & c2 & "',Oquantity='" & c3 & "',Namepatient ='" & c4 & "',Bloodtype ='" & c5 & "',mobilenumber ='" & c6 & "' where Nid = '" & c7 & "'"
        Dim CmdUpdate As New OleDbCommand(Supdate, cn2)
        CmdUpdate.ExecuteNonQuery()

        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        DropDownList1.Text = ""
        Response.Write("record updated")
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        dbcoon()
        dbsearch()
        cn2.Close()
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        TextBox3.Text = Calendar1.SelectedDate.ToString()
        Calendar1.Visible = False
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Calendar1.Visible = True
    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        dbcoon()
        dbupdate()
        cn2.Close()
    End Sub
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("profileneedy.aspx")
    End Sub

    Protected Sub CustomValidator2_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator2.ServerValidate
        If Len(args.Value) < 6 Or Len(args.Value) > 10 Then


            args.IsValid = False

        Else

            args.IsValid = True

        End If
    End Sub
End Class
