﻿Imports System.Data.OleDb
Imports System.IO
Partial Class camp
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second, third, four, five, six, seven, eight, nine As String

    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Public Sub dbsearch()
        Dim c1, Sreach As String
        c1 = TextBox2.Text
        Sreach = "Select Orderid, Nid, Deliveryaddress, Deliverydate, Oquantity, Orderdate, Namepatient, Bloodtype, mobilenumber from OrderInfo where Nid = '" & c1 & "'"
        'Label1.Text = "Word " & c1
        Dim CmdSearch As New OleDbCommand(Sreach, cn2)
        Dim Sread As OleDbDataReader
        Sread = CmdSearch.ExecuteReader
        Dim Sresult As New StringBuilder
        Do While Sread.Read
            first = Sread.GetValue(0).ToString()
            second = Sread.GetString(1).ToString()
            third = Sread.GetString(2).ToString()
            four = Sread.GetString(3).ToString()
            five = Sread.GetString(4).ToString()
            six = Sread.GetString(5).ToString()
            seven = Sread.GetString(6).ToString()
            eight = Sread.GetString(7).ToString()
            nine = Sread.GetString(8).ToString()
        Loop
        TextBox1.Text = first
        TextBox2.Text = second
        TextBox3.Text = third
        TextBox4.Text = four
        TextBox5.Text = five
        TextBox6.Text = six
        TextBox7.Text = seven
        TextBox8.Text = eight
        TextBox9.Text = nine
        Response.Write("Record Searched")
    End Sub
    Public Sub addnewrecord1()
        Dim c1, c2, c3, qinsert As String
        c1 = TextBox1.Text
        c2 = TextBox2.Text
        c3 = CheckBox1.Text

        qinsert = "insert into  deliveryconfirm ( Orderid , Nid , deliverystatus) values ('" & c1 & "','" & c2 & "','" & c3 & "')"
        Dim cmdInsert As New OleDbCommand(qinsert, cn2)
        cmdInsert.ExecuteNonQuery()
        Response.Write("Data recorded!")
    End Sub



    Public Sub addnewrecord()
        Dim c1, c2, c3, qinsert As String
        c1 = TextBox5.Text
        c2 = TextBox8.Text
        c3 = TextBox10.Text
      
        qinsert = "insert into  Bloodbank ( Bloodtype , Bloodquantity , BloodStation) values ('" & c2 & "','" & c1 & "','" & c3 & "')"
        Dim cmdInsert As New OleDbCommand(qinsert, cn2)
        cmdInsert.ExecuteNonQuery()
        Response.Write("Data recorded!")
    End Sub


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        dbcoon()
        dbsearch()
        cn2.Close()
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        dbcoon()
        addnewrecord()
        cn2.Close()
        dbcoon()
        addnewrecord1()
        cn2.Close()

    End Sub
End Class
