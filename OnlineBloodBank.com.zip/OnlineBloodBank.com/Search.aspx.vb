﻿Imports System.Data.OleDb
Imports System.IO
Partial Class Search
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second As String
    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        DataList1.Visible = True


    End Sub

    Protected Sub bloodgroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dropdownlist1.SelectedIndexChanged

    End Sub

    Protected Sub DataList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataList1.SelectedIndexChanged
        Dropdownlist1.Text = DataList1.SelectedValue.ToString
        DataList1.Visible = False

    End Sub
End Class
