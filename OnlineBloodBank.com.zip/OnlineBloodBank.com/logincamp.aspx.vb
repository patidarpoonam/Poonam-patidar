﻿
Imports System.Data.OleDb
Imports System.IO
Partial Class logincamp
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second As String
    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Public Sub dbsearch()
        Dim Scname, Sreach As String
        Scname = TextBox1.Text
        Sreach = "Select campid,camppassword from camp where campid = '" & Scname & "'"
        'Label1.Text = "Word " & Scname
        Dim CmdSearch As New OleDbCommand(Sreach, cn2)
        Dim Sread As OleDbDataReader
        Sread = CmdSearch.ExecuteReader
        Dim Sresult As New StringBuilder

        Do While Sread.Read
            first = Sread.GetString(0).ToString()
            second = Sread.GetString(1).ToString()
        Loop
        Response.Write("Record Searched")
    End Sub
    Public Sub logincheck()
        If TextBox1.Text = first And TextBox2.Text = second Then
            If Session("sf") = "Guest" Or Session("sf") = "" Then
                Session("sf") = TextBox1.Text
                'Label1.Text = Session("sf")
                Response.Write("Login complete")
                Response.Redirect("camp.aspx")

            Else
                Response.Write("Already Login")
                TextBox1.Text = ""
                TextBox2.Text = ""
                'Label1.Text = Session("sf")
            End If
        Else
            TextBox1.Text = ""
            TextBox2.Text = ""
            Response.Write("Please enter correct username and password")
        End If
    End Sub
    Public Sub logincheck1()
        If TextBox1.Text = first And TextBox2.Text = second Then
            If Session("sf") = "Guest" Or Session("sf") = "" Then
                Session("sf") = TextBox1.Text
                'Label1.Text = Session("sf")
                Response.Write("Login complete")
                Response.Redirect("campdonar.aspx")

            Else
                Response.Write("Already Login")
                TextBox1.Text = ""
                TextBox2.Text = ""
                'Label1.Text = Session("sf")
            End If
        Else
            TextBox1.Text = ""
            TextBox2.Text = ""
            Response.Write("Please enter correct username and password")
        End If
    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        dbcoon()
        dbsearch()
        logincheck()
        cn2.Close()
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        dbcoon()
        dbsearch()
        logincheck1()
        cn2.Close()
    End Sub
End Class
