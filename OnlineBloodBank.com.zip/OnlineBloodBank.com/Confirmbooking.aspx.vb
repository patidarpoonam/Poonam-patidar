﻿Imports System.Data.OleDb
Imports System.IO
Partial Class Confirmbooking
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second, third, four, five, six As String

    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Public Sub dbsearch()
        Dim c1, Sreach As String
        c1 = TextBox1.Text
        Sreach = "Select shedid ,Ddate , Donarid, Bloodtype ,Bookingdate , Bookingstation from SheduleInfo where Donarid = '" & c1 & "'"
        'Label1.Text = "Word " & c1
        Dim CmdSearch As New OleDbCommand(Sreach, cn2)
        Dim Sread As OleDbDataReader
        Sread = CmdSearch.ExecuteReader
        Dim Sresult As New StringBuilder

        Do While Sread.Read
            first = Sread.GetValue(0).ToString()
            second = Sread.GetString(1).ToString()
            third = Sread.GetString(2).ToString()
            four = Sread.GetString(3).ToString()
            five = Sread.GetString(4).ToString()
            six = Sread.GetString(5).ToString()
        Loop
        TextBox1.Text = third
        TextBox2.Text = first
        TextBox3.Text = second
        TextBox4.Text = four
        TextBox5.Text = five
        TextBox6.Text = six
        Response.Write("Record Searched")
    End Sub
    Public Sub addnewrecord()
        Dim c1, c2, c3, c4, qinsert As String
        c1 = TextBox2.Text
        c2 = TextBox1.Text
        c3 = CheckBox1.Text
        c4 = TextBox6.Text
        qinsert = "insert into donationconfirm values (" & c1 & ",'" & c2 & "','" & c3 & "','" & c4 & "')"
        Dim cmdInsert As New OleDbCommand(qinsert, cn2)
        cmdInsert.ExecuteNonQuery()
        Response.Write("Data recorded!")
    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        dbcoon()
        dbsearch()
        cn2.Close()

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        dbcoon()
        addnewrecord()
        cn2.Close()
    End Sub
End Class
