﻿Imports System.Data.OleDb
Imports System.IO
Partial Class profiledonar
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second As String
    Protected itemcollect As BuildMethod

    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
   


    






End Class
