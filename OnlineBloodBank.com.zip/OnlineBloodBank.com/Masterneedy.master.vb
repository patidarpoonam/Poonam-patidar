﻿
Partial Class Masterneedy
    Inherits System.Web.UI.MasterPage
End Class

