﻿Imports System.Data.OleDb
Imports System.IO
Partial Class donationupdate
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim second, third, four, five, six As String
    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Public Sub dbsearch()
        Dim c1, Sreach As String
        c1 = "userid" 'Session("sf")
        Sreach = "Select shedid, Ddate, Donarid, Bloodtype, Bookingdate, Bookingstation from SheduleInfo where Donarid = '" & c1 & "'"
        'Label1.Text = "Word " & c1
        Dim CmdSearch As New OleDbCommand(Sreach, cn2)
        Dim Sread As OleDbDataReader
        Sread = CmdSearch.ExecuteReader
        Dim Sresult As New StringBuilder
        Do While Sread.Read
            second = Sread.GetString(1).ToString()
            four = Sread.GetString(3).ToString()
            six = Sread.GetString(5).ToString()
        Loop
        TextBox1.Text = second
        DropDownList1.SelectedItem.Text = four
        DropDownList2.SelectedItem.Text = six
        Response.Write("Record Searched")
    End Sub
    Public Sub dbupdate()
        Dim c2, c3, c4, c5, c6, Supdate As String

        c2 = TextBox1.Text
        c3 = "userid" 'Session("sf")
        c4 = DropDownList1.SelectedItem.Value
        c5 = Today().ToString
        c6 = DropDownList2.SelectedItem.Value
        'Supdate = "update custm1 set roll = 8, cname='bsonkatch', cadd='snkatc',cbalance=1200"
        Supdate = "update SheduleInfo set Ddate='" & c2 & "',Donarid='" & c3 & "',Bloodtype ='" & c4 & "',Bookingdate ='" & c5 & "',Bookingstation ='" & c6 & "' where Donarid = '" & c2 & "'"
        Dim CmdUpdate As New OleDbCommand(Supdate, cn2)
        CmdUpdate.ExecuteNonQuery()

        TextBox1.Text = ""

        DropDownList1.SelectedItem.Value = ""

        DropDownList2.SelectedItem.Value = ""

        Response.Write("record updated")
    End Sub
    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("profiledonar.aspx")
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        dbcoon()
        dbupdate()
        cn2.Close()
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        TextBox1.Text = Calendar1.SelectedDate.ToString()
        Calendar1.Visible = False
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        dbcoon()
        dbsearch()
        cn2.Close()
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Calendar1.Visible = True
    End Sub
End Class

