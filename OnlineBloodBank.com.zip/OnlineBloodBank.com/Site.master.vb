﻿Imports System.Data.OleDb
Imports System.IO
Partial Class Site
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("sf") = "" Then

            LinkButton1.Text = "Guest"
        Else
            LinkButton1.Text = Session("sf").ToString()
        End If
    End Sub
    Protected Sub LinkButton1_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        If LinkButton1.Text = "Guest" Then
            Response.Redirect("donarlogin.aspx")
        Else
            Session.Abandon()
            Response.Redirect("Default.aspx")
        End If
    End Sub

    Protected Sub NavigationMenu_MenuItemClick(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MenuEventArgs) Handles NavigationMenu.MenuItemClick

    End Sub
End Class

