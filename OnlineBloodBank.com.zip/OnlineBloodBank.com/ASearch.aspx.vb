﻿Imports System.Data.OleDb
Imports System.IO
Partial Class ASearch
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second As String
    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        DataList1.Visible = True


    End Sub

    Protected Sub bloodgroup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList1.SelectedIndexChanged

    End Sub

    Protected Sub DataList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataList1.SelectedIndexChanged
        Dropdownlist1.Text = DataList1.SelectedValue.ToString
        DataList1.Visible = False

    End Sub

    Protected Sub DataList2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataList2.SelectedIndexChanged
        Dropdownlist2.Text = DataList2.SelectedValue.ToString
        DataList2.Visible = False
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        DataList2.Visible = True
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        DataList3.Visible = True

    End Sub

    Protected Sub DropDownList3_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList3.SelectedIndexChanged

    End Sub

    Protected Sub DataList3_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataList3.SelectedIndexChanged
        DropDownList3.Text = DataList3.SelectedValue.ToString
        DataList3.Visible = False
    End Sub
End Class
