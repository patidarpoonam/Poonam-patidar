﻿Imports System.Data.OleDb
Imports System.IO
Partial Class RegDonar
    Inherits System.Web.UI.Page
    Dim cn2 As OleDbConnection
    Dim first, second As String
    Public Sub dbcoon()
        cn2 = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\upendra\Documents\Visual Studio 2010\WebSites\OnlineBloodBank.com\App_Data\BloodBank.mdb")
        cn2.Open()
        Response.Write("connected")
    End Sub
    Public Sub addnewrecord()
        Dim c1, c2, c3, c4, c5, c6, c7, qinsert As String
        c1 = TextBox1.Text
        c2 = TextBox3.Text
        c3 = DropDownList1.Text
        c4 = TextBox6.Text
        c5 = TextBox5.Text
        c6 = TextBox7.Text
        c7 = TextBox2.Text
        qinsert = "insert into  DonatorInfo values (" & c1 & ",'" & c2 & "','" & c3 & "','" & c4 & "','" & c5 & "','" & c6 & "','" & c7 & "')"
        Dim cmdInsert As New OleDbCommand(qinsert, cn2)
        cmdInsert.ExecuteNonQuery()
        Response.Write("Data recorded!")
    End Sub


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        dbcoon()
        addnewrecord()
        cn2.Close()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        TextBox5.Text = Calendar1.SelectedDate.ToString()

    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        If Len(args.Value) < 6 Or Len(args.Value) > 10 Then


            args.IsValid = False

        Else

            args.IsValid = True

        End If
    End Sub

    Protected Sub CustomValidator3_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator3.ServerValidate
        If Len(args.Value) < 6 Or Len(args.Value) > 10 Then


            args.IsValid = False

        Else

            args.IsValid = True

        End If
    End Sub

    Protected Sub CustomValidator2_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator2.ServerValidate
        If Len(args.Value) < 6 Or Len(args.Value) > 10 Then


            args.IsValid = False

        Else

            args.IsValid = True

        End If
    End Sub
End Class



