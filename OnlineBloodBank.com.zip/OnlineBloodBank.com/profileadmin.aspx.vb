﻿
Partial Class profileadmin
    Inherits System.Web.UI.Page

End Class
