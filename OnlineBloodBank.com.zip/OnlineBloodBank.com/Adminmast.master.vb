﻿
Partial Class Adminmast
    Inherits System.Web.UI.MasterPage
End Class

